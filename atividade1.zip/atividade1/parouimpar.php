<!DOCTYPE html>
<html lang="en">
<head>

    <title>PAR OU IMPAR</title>
</head>
<body>
  <h2>PAR OU IMPAR</h2>

    <form method="POST">
        <input type="number" name="num" placeholder="Digite um número">
        <button type="submit">Verificar</button>

    </form>

    <?php
    if($_POST){
        $num = $_POST["num"];
        if($num % 2 == 0){
            echo "<h3>O número $num é PAR.</h3>";
        } else {
            echo "<h3>O número $num é IMPAR.</h3>";
        }
    }
    ?>
    
</body>
</html>