<!DOCTYPE html>
<html lang="en">
<head>
    <title>QUIZ DE CONHECIMENTO COM CORREÇÃO</title>
</head>
<body>
    <h2>QUIZ DE CONHECIMENTO COM CORREÇÃO</h2>
    <form method="POST">
        <p>1. Qual é a capital da França?</p>
        <input type="text" name="resposta1" placeholder="Digite sua resposta">

        <p>2. Qual é o resultado de 5 + 3?</p>
        <input type="number" name="resposta2" placeholder="Digite sua resposta">

        <button type="submit">Enviar</button>
    </form>
    <?php
    if($_POST){
        $resposta1 = strtolower(trim($_POST["resposta1"]));
        $resposta2 = $_POST["resposta2"];

        $corretas = 0;

        if($resposta1 == "paris"){
            echo "<h3>Resposta 1: Correta!</h3>";
            $corretas++;
        } else {
            echo "<h3>Resposta 1: Incorreta. A resposta correta é Paris.</h3>";
        }

        if($resposta2 == 8){
            echo "<h3>Resposta 2: Correta!</h3>";
            $corretas++;
        } else {
            echo "<h3>Resposta 2: Incorreta. A resposta correta é 8.</h3>";
        }

        echo "<h3>Total de respostas corretas: $corretas</h3>";
    }
    ?>
    
</body>
</html>