<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sorteio de Número Aleatório</title>
</head>
<body>
    <h2>Sorteio de Número Aleatório</h2>
    <form method="POST">
        <label for="min">Valor Mínimo:</label>
        <input type="number" id="min" name="min" placeholder="Digite o valor mínimo">
        <label for="max">Valor Máximo:</label>
        <input type="number" id="max" name="max" placeholder="Digite o valor máximo">
        <button type="submit">Sortear</button>
    </form>

    <?php
    if($_POST){
        $min = $_POST["min"];
        $max = $_POST["max"];
        if(is_numeric($min) && is_numeric($max)){
            $numero = rand($min, $max);
            echo "<h3>O número sorteado é: $numero</h3>";
        } else {
            echo "<h3>Por favor, digite valores numéricos para os campos.</h3>";
        }
    }
    ?>
</body>
</html>