<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
     <h2>Cadastro Simples com Validação</h2>

    <form method="POST">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" placeholder="Digite seu nome">
        <br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Digite seu email">
        <br><br>
        <button type="submit">Cadastrar</button>

    </form>

    <?php
    if($_POST){
        $nome = $_POST["nome"];
        $email = $_POST["email"];

        if(empty($nome) || empty($email)){
            echo "<h3>Por favor, preencha todos os campos.</h3>";
        } else {
            echo "<h3>Cadastro realizado com sucesso!</h3>";
            echo "<p>Nome: $nome</p>";
            echo "<p>Email: $email</p>";
        }
    }
    ?>
</body>
</html>