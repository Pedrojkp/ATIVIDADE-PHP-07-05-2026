<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Verificação de Senha</h2>
    <form method="POST">
        <label for="senha">Digite a senha:</label>
        <input type="password" id="senha" name="senha" placeholder="Digite sua senha">
        <button type="submit">Verificar</button>
    </form>

    <?php
    if($_POST){
        $senha = $_POST["senha"];
        $senhaCorreta = "minhasenha123";

        if($senha === $senhaCorreta){
            echo "<h3>Senha correta! Acesso concedido.</h3>";
        } else {
            echo "<h3>Senha incorreta! Acesso negado.</h3>";
        }
    }
    ?>
    
</body>
</html>