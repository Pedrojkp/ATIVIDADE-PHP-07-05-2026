<!DOCTYPE html>
<html lang="en">
<head>
    <title>SELEÇÂO DE CURSOS</title>
</head>
<body>
    <h2>SELECIONE SEU CURSO</h2>

    <form method="POST">
        <select name="curso">
            <option value="">Selecione um curso</option>
            <option value="informatica">Informática</option>
            <option value="enfermagem">Enfermagem</option>
            <option value="administração">Administração</option>
        </select>
        <button type="submit">Enviar</button>
    </form>

    <?php
    if($_POST){
        $curso = $_POST["curso"];
        if($curso == "informatica"){
            echo "<h3>Você selecionou o curso de Informática.</h3>";
        } elseif($curso == "enfermagem"){
            echo "<h3>Você selecionou o curso de Enfermagem.</h3>";
        } elseif($curso == "administração"){
            echo "<h3>Você selecionou o curso de Administração.</h3>";
        } else {
            echo "<h3>Nenhum curso selecionado.</h3>";
        }
    }
    ?>
           
</body>
</html>