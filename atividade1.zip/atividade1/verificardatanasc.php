<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<h2>Verificação de Data de Nascimento</h2>

<form method="POST">
    <label for="dataNascimento">Digite sua data de nascimento:</label>
    <input type="date" id="dataNascimento" name="dataNascimento">
    <button type="submit">Verificar</button>
</form>

<?php
if($_POST){
    $dataNascimento = $_POST["dataNascimento"];
    $dataAtual = date("Y-m-d");

    if($dataNascimento < $dataAtual){
        echo "<h3>Data de nascimento válida!</h3>";
    } else {
        echo "<h3>Data de nascimento inválida! Por favor, insira uma data no passado.</h3>";
    }
}
?>
    
</body>
</html>