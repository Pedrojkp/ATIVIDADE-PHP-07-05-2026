<!DOCTYPE html>
<html lang="en">
<head>
    <title>CAIXA DE COMENTÁRIO</title>
</head>
<body>
    <h2>DEIXE SEU COMENTÁRIO</h2>
    <form method="POST">
        <textarea name="comentario" placeholder="Digite seu comentário aqui..."></textarea>
        <button type="submit">Enviar</button>
    </form>

    <?php
    
    if($_POST){
        $comentario = $_POST["comentario"];
        if(!empty($comentario)){
            echo "<h3>Seu comentário: $comentario</h3>";
        } else {
            echo "<h3>Por favor, digite um comentário.</h3>";
        }
    }

    ?>

</body>
</html>