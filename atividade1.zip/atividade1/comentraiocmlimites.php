<html>
<head>
    <title>Comentários e Limites</title>
</head>
<body>
    <h2>Comentários e Limites de Caracteres</h2>
    <form method="POST">
        <label for="comentario">Deixe seu comentário (máximo 200 caracteres):</label><br>
        <textarea id="comentario" name="comentario" maxlength="200" placeholder="Digite seu comentário aqui..."></textarea><br>
        <button type="submit">Enviar Comentário</button>
    </form>
    <?php
    if($_POST){
        $comentario = $_POST["comentario"];
        if(empty($comentario)){
            echo "<h3>Por favor, digite um comentário antes de enviar.</h3>";
        } else {
            echo "<h3>Comentário recebido:</h3>";
            echo "<p>$comentario</p>";
        }
    }
    ?>
</body>
</html>