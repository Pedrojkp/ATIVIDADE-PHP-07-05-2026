<!DOCTYPE html>
<html lang="en">
<head>
    <title>MAIOR IDADE</title>
</head>
<body>
    <h2>Verificar Maior de Idade</h2>
    <form method="POST">
        <input type="number" name="idade" placeholder="Digite sua idade">
        <button type="submit">Verificar</button>
    </form>

    <?php
    if($_POST){
        $idade = $_POST["idade"];
        if($idade >= 18){
            echo "<h3>Você é maior de idade.</h3>";
        } else {
            echo "<h3>Você é menor de idade.</h3>";
        }
    }
    ?>
    
</body>
</html>