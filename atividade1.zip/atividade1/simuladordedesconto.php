<!DOCTYPE html>
<html lang="en">
<head>
  
    <title>Simulador de Desconto</title>
</head>
<body>
     <h2>Simulador de Desconto</h2>
    <form method="POST">
        <label for="preco">Preço Original:</label>
        <input type="number" id="preco" name="preco" step="0.01" placeholder="Digite o preço original">
        <label for="desconto">Desconto (%):</label>
        <input type="number" id="desconto" name="desconto" step="0.01" placeholder="Digite o percentual de desconto">
        <button type="submit">Calcular</button>
    </form>

    <?php
    if($_POST){
        $preco = $_POST["preco"];
        $desconto = $_POST["desconto"];
        if(is_numeric($preco) && is_numeric($desconto)){
            $valorDesconto = ($preco * $desconto) / 100;
            $precoFinal = $preco - $valorDesconto;
            echo "<h3>O preço final com desconto é: R$ " . number_format($precoFinal, 2, ',', '.') . "</h3>";
        } else {
            echo "<h3>Por favor, digite valores numéricos para o preço e o desconto.</h3>";
        }
    }
    ?>
</body>
</html>