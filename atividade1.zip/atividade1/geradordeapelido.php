<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>GERADOR DE APELIDO PERSONALIZADO</title>
</head>
<body>
     <h2>GERADOR DE APELIDO PERSONALIZADO</h2>

    <form method="POST">
        <input type="text" name="nome" placeholder="Digite seu nome">
        <button type="submit">Gerar Apelido</button>
    </form>

    <?php
    if($_POST){
        $nome = $_POST["nome"];
        if(!empty($nome)){
            $apelido = substr($nome, 0, 3) . rand(100, 999);
            echo "<h3>Seu apelido personalizado é: $apelido</h3>";
        } else {
            echo "<h3>Por favor, digite seu nome.</h3>";
        }
    }
    ?>
</body>
</html>