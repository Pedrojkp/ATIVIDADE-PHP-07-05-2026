<!DOCTYPE html>
<html lang="en">
<head>

    
    <title>Document</title>
</head>
<body>
    <h2>Digite seu nome</h2>

    <form method="POST">
        <input type="text" name="nome">
        <button type="submit">Enviar</button>
    </form>

    <?php

    if($_POST){
        $nome = $_POST["nome"];
        echo "<h3>Olá, $nome! Seja bem-vindo(a)!</h3>";
    }

    ?>

</body>
</html>