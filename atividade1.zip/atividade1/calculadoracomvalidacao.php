<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
   <h2>Calculadora com Validação</h2>


    <form method="POST">
        <label for="num1">Número 1:</label>
        <input type="number" id="num1" name="num1" step="0.01" placeholder="Digite o primeiro número">
        <br><br>
        <label for="num2">Número 2:</label>
        <input type="number" id="num2" name="num2" step="0.01" placeholder="Digite o segundo número">
        <br><br>
        <button type="submit">Calcular</button>

    </form>

    <?php
    if($_POST){
        $num1 = $_POST["num1"];
        $num2 = $_POST["num2"];

        if(is_numeric($num1) && is_numeric($num2)){
            $soma = $num1 + $num2;
            echo "<h3>A soma de $num1 e $num2 é: $soma</h3>";
        } else {
            echo "<h3>Por favor, digite valores numéricos para ambos os campos.</h3>";
        }
    }
    ?>
    
</body>
</html>