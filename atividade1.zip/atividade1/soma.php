<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Document</title>
</head>
<body>
    <h2>Soma de Números</h2>

    <form method="POST">
        <input type="number" name="num1" placeholder="Digite o primeiro número">
        <input type="number" name="num2" placeholder="Digite o segundo número">
        <button type="submit">Calcular</button>
    </form>

    <?php

    if($_POST){
        $num1 = $_POST["num1"];
        $num2 = $_POST["num2"];
        $soma = $num1 + $num2;
        echo "<h3>A soma de $num1 e $num2 é: $soma</h3>";
    }

    ?>
    
</body>
</html>