<!DOCTYPE html>
<html lang="pt-bt">
<head>
    <title>Conversor de Temperatura</title>
</head>
<body>
    <h2>Conversor de Temperatura</h2>
    
    <form method="POST">
        <label for="celsius">Temperatura em Celsius:</label>
        <input type="number" id="celsius" name="celsius" step="0.01" placeholder="Digite a temperatura em Celsius">
        <button type="submit">Converter</button>
    </form>

    <?php
    if($_POST){
        $celsius = $_POST["celsius"];
        if(is_numeric($celsius)){
            $fahrenheit = ($celsius * 9/5) + 32;
            echo "<h3>$celsius °C é igual a $fahrenheit °F</h3>";
        } else {
            echo "<h3>Por favor, digite um valor numérico para a temperatura em Celsius.</h3>";
        }
    }
    
    ?>

</body>
</html>